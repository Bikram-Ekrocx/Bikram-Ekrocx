


// ======================= section recently-views functionality start =======================

    // Function to set recently viewed product data
    function setRecentlyViewedPdp() {
        // Retrieve product data from wherever it's available
        const productData = {
            productTitle: "Product Title", // Replace with actual product title
            productImg: "product-image.jpg", // Replace with actual product image URL
            productPrice: "$10.00", // Replace with actual product price
            productUrl: "product-url" // Replace with actual product URL
        };

        // Retrieve existing recently viewed products from local storage or initialize an empty array
        const existingData = localStorage.getItem('recently_viewed');
        const recentProducts = existingData ? JSON.parse(existingData) : [];

        // Check if the product is already in the recently viewed list
        const isProductViewed = recentProducts.some(item => item.productTitle === productData.productTitle);

        // Add the product to the recently viewed list if it's not already there
        if (!isProductViewed) {
            recentProducts.unshift(productData); // Add the product to the beginning of the array
            recentProducts.splice(4); // Limit the array length to 4 (or any desired number of recent products)
            localStorage.setItem('recently_viewed', JSON.stringify(recentProducts)); // Save the updated list to local storage
        }
    }

    // Function to get recently viewed products and display them on the page
    function getRecentPdp() {
        const recentProducts = JSON.parse(localStorage.getItem('recently_viewed')) || [];

        // Filter out any empty or invalid product data
        const validRecentProducts = recentProducts.filter(item =>
            item.productTitle && item.productImg && item.productPrice && item.productUrl
        );

        // Generate HTML for each recently viewed product with unique IDs
        const recentViewHtml = validRecentProducts.map((item, index) => `
            <section id="Recent${index + 1}">
                <div class="c-product">
                    <div class="c-product__img">
                        <a href="${item.productUrl}"><img src='${item.productImg}'/></a>
                    </div>
                    <h3 class="c-product__title">
                        <a class="c-product__url" href="${item.productUrl}">
                            ${item.productTitle}
                        </a>
                    </h3>
                    <p class="c-productPrice">${item.productPrice}</p>
                </div>
            </section>
        `).join('');

        // Display the recently viewed products on the page
        document.querySelector('.js-recentPdpBlock').innerHTML = recentViewHtml;
    }

    // Call the functions when the DOM content is loaded
    document.addEventListener('DOMContentLoaded', function () {
        setRecentlyViewedPdp();
        getRecentPdp();
    });
 // ======================= section recently-views functionality end =======================



// =========================== section metaobject-section functionality start ========================
  $(document).ready(function(){
    $('.meta-content').slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1
    });
  });



// $(document).ready(function(){
  //  $('.my-slide-class').slick({
  //   infinite: true,
  //   slidesToShow: 3,
  //   slidesToScroll: 1
  // });
// });


  $(document).ready(function(){
    $(".owl-carousel").owlCarousel({
      loop:false,
      margin: 10,
      nav: true,
      responsive:{
        0:{
          items:1
        },
        600:{
          items:3
        },
        1000:{
          items:5
        }
      }
    });
  });
// // =========================== section metaobject-section functionality end ========================
